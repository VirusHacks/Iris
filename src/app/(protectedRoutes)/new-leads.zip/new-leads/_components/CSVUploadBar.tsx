"use client";

import { useState } from "react";
import { Upload, FileText, Loader2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";

export default function CSVUploadBar({ onUploadSuccess }: { onUploadSuccess?: () => void }) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStats, setUploadStats] = useState<any>(null);
  const router = useRouter();

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith(".csv")) {
      toast.error("Please upload a CSV file");
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/leads/upload", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to upload CSV");
      }

      setUploadStats({
        processed: data.stats?.processed || 0,
        newLeads: data.stats?.newLeads || 0,
        updated: data.stats?.updated || 0,
      });

      toast.success(
        `CSV processed successfully! ${data.stats?.newLeads || 0} new leads added, ${data.stats?.updated || 0} updated.`
      );

      // Refresh the page to show updated data
      router.refresh();
      
      if (onUploadSuccess) {
        onUploadSuccess();
      }
    } catch (error) {
      console.error("Upload error:", error);
      toast.error(error instanceof Error ? error.message : "Failed to upload CSV");
    } finally {
      setIsUploading(false);
      // Reset file input
      event.target.value = '';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="bg-gradient-to-r from-[#0a0a0a] via-purple-500/10 to-[#0a0a0a] border border-purple-500/30 hover:border-purple-500/50 transition-all duration-300 h-full">
        <CardContent className="p-4 h-full flex flex-col">
          <div className="space-y-3 flex-1">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Upload className="h-5 w-5 text-purple-400" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white">Upload New Leads CSV</h3>
                <p className="text-xs text-gray-400">Import leads from a CSV file</p>
              </div>
            </div>
            
            {uploadStats && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col gap-1 text-xs text-gray-300 bg-green-500/10 border border-green-500/30 px-2 py-1.5 rounded-lg"
              >
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3 text-green-400" />
                  <span className="font-bold text-green-400">{uploadStats.processed}</span>
                  <span>processed</span>
                </div>
                {uploadStats.newLeads > 0 && (
                  <div className="text-purple-400 ml-5">
                    +{uploadStats.newLeads} new leads
                  </div>
                )}
                {uploadStats.updated > 0 && (
                  <div className="text-blue-400 ml-5">
                    {uploadStats.updated} updated
                  </div>
                )}
              </motion.div>
            )}
          </div>
          
          <div className="mt-auto pt-6">
            <label htmlFor="leads-csv-upload" className="w-full">
              <Button
                asChild
                variant="outline"
                className="cursor-pointer w-full bg-purple-500/10 border-purple-500/50 text-white hover:bg-purple-500/20 hover:border-purple-500 transition-all"
                disabled={isUploading}
              >
                <span>
                  {isUploading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Choose CSV File
                    </>
                  )}
                </span>
              </Button>
            </label>
            <input
              id="leads-csv-upload"
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="hidden"
              disabled={isUploading}
            />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

