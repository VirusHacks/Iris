"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

type Props = {
  totalLeads: number;
  convertedLeads: number;
  conversionRate: number;
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0];
    return (
      <div className="bg-[#0a0a0a] border border-gray-700 rounded-lg p-3 shadow-xl">
        <p className="font-semibold text-sm text-white mb-2">{data.name}</p>
        <p className="text-sm font-bold text-purple-400">{data.value} leads</p>
      </div>
    );
  }
  return null;
};

export default function ConversionRateChart({ totalLeads, convertedLeads, conversionRate }: Props) {
  const data = [
    {
      name: "Converted",
      value: convertedLeads,
      color: "#10b981", // emerald
    },
    {
      name: "Not Converted",
      value: totalLeads - convertedLeads,
      color: "#6b7280", // gray
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="bg-[#0a0a0a] border border-gray-800 hover:border-purple-500/30 transition-all duration-300">
      <CardHeader className="border-b border-gray-800">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              Lead Conversion Rate
            </CardTitle>
            <CardDescription className="mt-1 text-gray-400 text-sm">
              {convertedLeads} out of {totalLeads} leads converted ({conversionRate}%)
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="bg-black rounded-lg p-4">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={data} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1f1f1f" opacity={0.5} />
              <XAxis 
                type="number" 
                stroke="#666"
                tick={{ fill: "#999", fontSize: 12 }}
                tickLine={{ stroke: "#333" }}
              />
              <YAxis 
                dataKey="name" 
                type="category" 
                width={120}
                stroke="#666"
                tick={{ fill: "#999", fontSize: 12 }}
                tickLine={{ stroke: "#333" }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
    </motion.div>
  );
}

