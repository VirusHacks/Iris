"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Coins, Users, TrendingUp, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";

type Props = {
  creditsEarned: number;
  clientsConverted: number;
  conversionRate: number;
};

export default function CreditsStats({
  creditsEarned,
  clientsConverted,
  conversionRate,
}: Props) {
  const [animatedCredits, setAnimatedCredits] = useState(0);
  const [animatedClients, setAnimatedClients] = useState(0);

  useEffect(() => {
    // Animate numbers counting up
    const duration = 2000;
    const steps = 60;
    const increment = creditsEarned / steps;
    const clientIncrement = clientsConverted / steps;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      setAnimatedCredits(Math.min(increment * currentStep, creditsEarned));
      setAnimatedClients(
        Math.min(clientIncrement * currentStep, clientsConverted)
      );

      if (currentStep >= steps) {
        clearInterval(timer);
        setAnimatedCredits(creditsEarned);
        setAnimatedClients(clientsConverted);
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [creditsEarned, clientsConverted]);

  const stats = [
    {
      label: "Credits Earned",
      value: Math.floor(animatedCredits),
      icon: Coins,
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/10",
      description: "Total credits from conversions",
    },
    {
      label: "Clients Converted",
      value: Math.floor(animatedClients),
      icon: Users,
      color: "text-emerald-400",
      bgColor: "bg-emerald-500/10",
      description: "Successful conversions",
    },
    {
      label: "Conversion Rate",
      value: conversionRate.toFixed(1),
      icon: TrendingUp,
      color: "text-purple-400",
      bgColor: "bg-purple-500/10",
      description: "Overall success rate",
      suffix: "%",
    },
  ];

  return (
    <div className="flex items-center gap-3">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: index * 0.1 }}
          whileHover={{ scale: 1.08, y: -3 }}
          className="cursor-pointer"
        >
          <Card
            className={`bg-[#0a0a0a] hover:shadow-lg hover:shadow-${stat.color.split("-")[1]}-500/20 transition-all duration-300`}
          >
            <CardContent className="p-3">
              <div className="flex items-center justify-between gap-3">
                <div className={`${stat.bgColor} p-2 rounded-lg`}>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-medium text-gray-400 truncate">
                    {stat.label}
                  </p>
                  <motion.p
                    key={stat.value}
                    initial={{ scale: 1.3, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className={`text-lg font-bold ${stat.color} leading-tight`}
                  >
                    {stat.value}
                    {stat.suffix && (
                      <span className="text-sm">{stat.suffix}</span>
                    )}
                  </motion.p>
                </div>
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{
                    duration: 0.6,
                    delay: index * 0.15,
                    repeat: Infinity,
                    repeatDelay: 3,
                  }}
                >
                  <Zap className="h-3 w-3 text-gray-600" />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
