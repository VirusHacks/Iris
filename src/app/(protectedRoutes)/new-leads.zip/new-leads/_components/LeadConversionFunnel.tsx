"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Target, TrendingDown } from "lucide-react";
import { motion } from "framer-motion";

type Props = {
  totalLeads: number;
  contactedLeads: number;
  qualifiedLeads: number;
  convertedLeads: number;
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0];
    return (
      <div className="bg-[#0a0a0a] border border-gray-700 rounded-lg p-3 shadow-xl">
        <p className="font-semibold text-sm text-white mb-2">{data.name}</p>
        <p className="text-sm font-bold text-purple-400">{data.value} leads</p>
        {data.payload.percentage && (
          <p className="text-xs text-gray-400 mt-1">{data.payload.percentage}% of total</p>
        )}
      </div>
    );
  }
  return null;
};

export default function LeadConversionFunnel({
  totalLeads,
  contactedLeads,
  qualifiedLeads,
  convertedLeads,
}: Props) {
  // Calculate percentages
  const contactedPct = totalLeads > 0 ? ((contactedLeads / totalLeads) * 100).toFixed(1) : "0";
  const qualifiedPct = totalLeads > 0 ? ((qualifiedLeads / totalLeads) * 100).toFixed(1) : "0";
  const convertedPct = totalLeads > 0 ? ((convertedLeads / totalLeads) * 100).toFixed(1) : "0";

  const data = [
    {
      name: "Total Leads",
      value: totalLeads,
      color: "#3b82f6",
      percentage: "100%",
    },
    {
      name: "Contacted",
      value: contactedLeads,
      color: "#8b5cf6",
      percentage: `${contactedPct}%`,
    },
    {
      name: "Qualified",
      value: qualifiedLeads,
      color: "#a78bfa",
      percentage: `${qualifiedPct}%`,
    },
    {
      name: "Converted",
      value: convertedLeads,
      color: "#10b981",
      percentage: `${convertedPct}%`,
    },
  ];

  // Calculate drop-off rates
  const contactDropOff = totalLeads > 0 ? ((1 - contactedLeads / totalLeads) * 100).toFixed(1) : "0";
  const qualifyDropOff = contactedLeads > 0 ? ((1 - qualifiedLeads / contactedLeads) * 100).toFixed(1) : "0";
  const convertDropOff = qualifiedLeads > 0 ? ((1 - convertedLeads / qualifiedLeads) * 100).toFixed(1) : "0";

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="bg-[#0a0a0a] border border-gray-800 hover:border-purple-500/30 transition-all duration-300">
        <CardHeader className="border-b border-gray-800">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
                <Target className="h-4 w-4 text-purple-400" />
                Lead Conversion Funnel
              </CardTitle>
              <CardDescription className="mt-1 text-gray-400 text-sm">
                Track your lead progression through each stage
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="bg-black rounded-lg p-4">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f1f1f" opacity={0.5} />
                <XAxis
                  dataKey="name"
                  stroke="#666"
                  tick={{ fill: "#999", fontSize: 12 }}
                  tickLine={{ stroke: "#333" }}
                />
                <YAxis
                  stroke="#666"
                  tick={{ fill: "#999", fontSize: 12 }}
                  tickLine={{ stroke: "#333" }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Drop-off Analysis */}
          <div className="mt-6 grid grid-cols-3 gap-4 pt-4 border-t border-gray-800">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
              <div className="flex items-center justify-center gap-1 text-red-400 mb-1">
                <TrendingDown className="h-3 w-3" />
                <span className="text-xs font-medium">Contact Drop-off</span>
              </div>
              <p className="text-lg font-bold text-white">{contactDropOff}%</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-center"
            >
              <div className="flex items-center justify-center gap-1 text-orange-400 mb-1">
                <TrendingDown className="h-3 w-3" />
                <span className="text-xs font-medium">Qualify Drop-off</span>
              </div>
              <p className="text-lg font-bold text-white">{qualifyDropOff}%</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-center"
            >
              <div className="flex items-center justify-center gap-1 text-yellow-400 mb-1">
                <TrendingDown className="h-3 w-3" />
                <span className="text-xs font-medium">Convert Drop-off</span>
              </div>
              <p className="text-lg font-bold text-white">{convertDropOff}%</p>
            </motion.div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

