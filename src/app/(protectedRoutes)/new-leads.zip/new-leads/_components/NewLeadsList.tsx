"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Users } from "lucide-react";
import { motion } from "framer-motion";

type Lead = {
  id: string;
  name: string;
  email: string;
  phone: string;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
};

type Props = {
  leads: Lead[];
};

export default function NewLeadsList({ leads }: Props) {
  if (leads.length === 0) {
    return (
      <Card className="bg-[#0a0a0a] border border-gray-800">
        <CardContent className="p-6">
          <div className="flex flex-col items-center justify-center h-[400px] gap-4">
            <Users className="w-12 h-12 text-gray-600" />
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white">No new leads yet</h3>
              <p className="text-sm text-gray-400">
                New leads from the last 30 days will appear here
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[#0a0a0a] border border-gray-800">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">New Leads</h2>
            <span className="text-sm text-gray-400">{leads.length} leads</span>
          </div>
          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {leads.map((lead, index) => (
              <motion.div
                key={lead.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ scale: 1.02, x: 5 }}
                className="bg-black border border-gray-800 rounded-lg p-4 hover:border-purple-500/50 transition-all cursor-pointer"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm text-white mb-1">{lead.name}</h3>
                    <p className="text-xs text-gray-400 mb-2">{lead.email}</p>
                  </div>
                  <span className="text-xs text-gray-500">
                    {format(new Date(lead.createdAt), "MMM d, yyyy")}
                  </span>
                </div>
                {lead.tags && lead.tags.length > 0 && (
                  <div className="flex gap-2 flex-wrap mt-3">
                    {lead.tags.map((tag, index) => (
                      <Badge
                        key={index}
                        variant="outline"
                        className="text-xs bg-gray-900 border-gray-700 text-gray-300"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

