"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Send, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

type Props = {
  totalLeads: number;
};

export default function OfferMessage({ totalLeads }: Props) {
  const [offerMessage, setOfferMessage] = useState(
    "🎉 Special Offer! Get 20% off on your first purchase. Limited time only!"
  );
  const [sendToAll, setSendToAll] = useState(false);

  const handleSend = () => {
    if (!offerMessage.trim()) {
      toast.error("Please enter an offer message");
      return;
    }

    if (sendToAll) {
      toast.success(`Offer message sent to all ${totalLeads} contacts!`);
    } else {
      toast.info("Offer message ready. Select 'Send to all contacts' to send.");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="bg-[#0a0a0a] border border-gray-800 hover:border-purple-500/30 transition-all duration-300">
      <CardHeader className="border-b border-gray-800">
        <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
          <MessageSquare className="h-4 w-4 text-purple-400" />
          New Offer Message
        </CardTitle>
        <CardDescription className="text-gray-400 text-sm">
          Create and send a special offer to your leads
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div className="space-y-2">
          <Label htmlFor="offer-message" className="text-sm font-medium text-gray-300">
            Offer Message
          </Label>
          <Textarea
            id="offer-message"
            value={offerMessage}
            onChange={(e) => setOfferMessage(e.target.value)}
            placeholder="Enter your offer message here..."
            className="bg-black border-gray-700 text-white placeholder:text-gray-500 min-h-[120px] resize-none"
          />
        </div>

        <div className="flex items-center space-x-2 pt-2 border-t border-gray-800">
          <Checkbox
            id="send-to-all"
            checked={sendToAll}
            onCheckedChange={(checked) => setSendToAll(checked as boolean)}
            className="border-gray-700 data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500 data-[state=checked]:text-white"
          />
          <Label
            htmlFor="send-to-all"
            className="text-sm font-medium text-gray-300 cursor-pointer flex-1"
          >
            Send offer message to all {totalLeads} contacts
          </Label>
        </div>

        <Button
          onClick={handleSend}
          className="w-full bg-purple-500 hover:bg-purple-600 text-white"
        >
          <Send className="h-4 w-4 mr-2" />
          {sendToAll ? `Send to All ${totalLeads} Contacts` : "Save Offer Message"}
        </Button>
      </CardContent>
    </Card>
    </motion.div>
  );
}

